// -*- tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
// vi: set et ts=4 sw=2 sts=2:
#ifndef DUNE_GRID_COMMON_VIRTUALREFINEMENT_HH
#define DUNE_GRID_COMMON_VIRTUALREFINEMENT_HH

#warning This header is deprecated and will be removed after Dune 2.3.\
  Use <dune/geometry/virtualrefinement.hh> instead.

#include <dune/geometry/virtualrefinement.hh>

#endif //DUNE_GRID_COMMON_VIRTUALREFINEMENT_HH
