// -*- tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
// vi: set et ts=4 sw=2 sts=2:
#ifndef DUNE_MPIHELPER
#warning dune/common/mpihelper.hh is deprecated, please use dune/common/parallel/mpihelper.hh
#include "parallel/mpihelper.hh"
#endif
